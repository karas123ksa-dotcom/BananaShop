BananaPvP Lite 1.21.11
Zawiera lekkie tekstury zelaznej i netheritowej zbroi w motywie banana.
Wloz ZIP do .minecraft/resourcepacks i wlacz w Ustawienia > Pakiety zasobow.
