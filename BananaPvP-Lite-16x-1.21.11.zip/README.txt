BananaPvP Lite 1.21.11
W paczce znajduja sie lekkie, zmienione tekstury ikon netherite armor oraz tekstury noszonej zbroi.
Wloz ZIP do .minecraft/resourcepacks i wlacz go w Ustawienia > Pakiety zasobow.
